import React, { Component } from 'react'
import UserManagement from './UserManagement'

export default class AllsignedUsers extends Component {
    render() {
        return <UserManagement />
    }
}

