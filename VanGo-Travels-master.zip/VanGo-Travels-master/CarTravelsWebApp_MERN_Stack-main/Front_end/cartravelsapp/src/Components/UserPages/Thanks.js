import React, { Component } from 'react'

export default class Thanks extends Component {
  
    render() {
        return (
        <div className="MainDiv">
            <div className="thankyou">
                <h1>THANK YOU!</h1>
                <i className="fas fa-check fa-5x"></i>
                <p>Your Booking was successful</p>
                <p>We will contact you.</p>
                <h2>Happy Journey</h2>
            </div>
      </div>

        )
    }
}
